import numpy as np

# Create a 1x28 vector using arange
vector_1x28 = np.zeros(28)

print(vector_1x28.size)
print(vector_1x28)
